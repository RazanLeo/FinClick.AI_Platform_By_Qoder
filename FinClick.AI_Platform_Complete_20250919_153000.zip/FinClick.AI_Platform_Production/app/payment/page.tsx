import { Payment } from "@/components/payment"

export default function PaymentPage() {
  return <Payment />
}